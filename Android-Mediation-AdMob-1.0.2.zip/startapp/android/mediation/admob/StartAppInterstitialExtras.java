package com.startapp.android.mediation.admob;

import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEventExtras;
import com.startapp.android.publish.adsCommon.StartAppAd.AdMode;

public class StartAppInterstitialExtras extends StartAppExtras {

	private AdMode adMode;
	
	private StartAppInterstitialExtras(){
		super();
	}
	
	public AdMode getAdMode() {
		return adMode;
	}
	
	public StartAppExtras setAdMode(AdMode adMode) {
		this.adMode = adMode;
		return this;
	}
	
	public static class Builder{
		
		private StartAppInterstitialExtras extras;
		
		public Builder() {
			extras = new StartAppInterstitialExtras();
		}
		
		public Builder setAdMode(AdMode adMode) {
			extras.setAdMode(adMode);
			return this;
		}
		
		public Builder setAdTag(String adTag) {
			extras.setAdTag(adTag);
			return this;
		}
		
		public NetworkExtras build(String label) {
		    CustomEventExtras customEventExtras = new CustomEventExtras();
		    customEventExtras.setExtra(label, extras);
		    
		    return customEventExtras;
		}
		
	}
}
