package com.startapp.android.mediation.admob;


public class StartAppExtras {

	private String adTag;
	
	protected StartAppExtras() {
	}
	
	public String getAdTag() {
		return adTag;
	}
	
	public StartAppExtras setAdTag(String adTag) {
		this.adTag = adTag;
		return this;
	}

}
