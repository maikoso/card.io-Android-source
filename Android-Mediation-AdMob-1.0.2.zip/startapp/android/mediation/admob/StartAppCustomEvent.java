package com.startapp.android.mediation.admob;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import com.startapp.android.publish.ads.banner.Banner;
import com.startapp.android.publish.ads.banner.BannerListener;
import com.startapp.android.publish.ads.banner.banner3d.Banner3D;
import com.startapp.android.publish.ads.banner.bannerstandard.BannerStandard;
import com.startapp.android.publish.adsCommon.Ad;
import com.startapp.android.publish.adsCommon.SDKAdPreferences;
import com.startapp.android.publish.adsCommon.StartAppAd.*;
import com.startapp.android.publish.adsCommon.StartAppAd;
import com.startapp.android.publish.ads.banner.*;
import com.startapp.android.publish.adsCommon.adListeners.AdDisplayListener;
import com.startapp.android.publish.adsCommon.adListeners.AdEventListener;
import com.google.ads.AdRequest.Gender;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.customevent.CustomEventBanner;
import com.google.ads.mediation.customevent.CustomEventBannerListener;
import com.google.ads.mediation.customevent.CustomEventInterstitial;
import com.google.ads.mediation.customevent.CustomEventInterstitialListener;
import com.startapp.android.publish.common.model.AdPreferences;

public class StartAppCustomEvent implements CustomEventBanner, CustomEventInterstitial{

	private StartAppAd ad;

	private CustomEventInterstitialListener interstitialListener;

//	@Override
	public void requestInterstitialAd(final CustomEventInterstitialListener listener,
			Activity activity,
			String label, 
			String serverParameter,
			MediationAdRequest mediationAdRequest,
			Object customEventExtra) {

		interstitialListener = listener;

		ad = new StartAppAd(activity);
		ad.loadAd(getAdMode(serverParameter, customEventExtra), extractAdPrefs(activity, mediationAdRequest, customEventExtra), 
				new AdEventListener(){
//			@Override
			public void onReceiveAd(Ad arg0) {
				listener.onReceivedAd();
			}
//			@Override
			public void onFailedToReceiveAd(Ad arg0) {
				listener.onFailedToReceiveAd();
			}
		});
	}

	private AdMode getAdMode(String serverParameter, Object customEventExtra) {
		if (serverParameter != null) {
			if (serverParameter.equalsIgnoreCase("AdMode.FULLPAGE")) {
				return AdMode.FULLPAGE;
			} else if (serverParameter.equalsIgnoreCase("AdMode.OVERLAY")) {
				return AdMode.OVERLAY;
			} else if (serverParameter.equalsIgnoreCase("AdMode.OFFERWALL")) {
				return AdMode.OFFERWALL;
			} else if (serverParameter.equalsIgnoreCase("AdMode.AUTOMATIC")) {
				return AdMode.AUTOMATIC;
			}
		}
		if (customEventExtra instanceof StartAppInterstitialExtras) {
			AdMode mode = ((StartAppInterstitialExtras)customEventExtra).getAdMode();
			if (mode != null) {
				return mode; 
			}
		}
		return AdMode.AUTOMATIC;
	}

//	@Override
	public void showInterstitial() {
		ad.showAd(new AdDisplayListener(){
//			@Override
			public void adHidden(Ad ad) {
				interstitialListener.onDismissScreen();
			}
//			@Override
			public void adDisplayed(Ad ad) {
				interstitialListener.onPresentScreen();
			}
//			@Override
			public void adClicked(Ad ad) {
				interstitialListener.onLeaveApplication();
			}
//            @Override
            public void adNotDisplayed(Ad ad) {
                // do nothing
            }
		});
	}
	
//	@Override
	public void requestBannerAd(final CustomEventBannerListener listener,
			final Activity activity,
			String label,
			String serverParameter,
			AdSize adSize,
			MediationAdRequest request,
			Object customEventExtra) {

		AdPreferences prefs = extractAdPrefs(activity, request, customEventExtra);

		final FrameLayout frameLayout = new FrameLayout(activity);
		frameLayout.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

		BannerListener bannerListener = new BannerListener() {

//			@Override
			public void onReceiveAd(View banner) {
				listener.onReceivedAd(frameLayout);
			}

//			@Override
			public void onFailedToReceiveAd(View banner) {
				listener.onFailedToReceiveAd();
			}

//			@Override
			public void onClick(View banner) {
				listener.onClick();
				listener.onPresentScreen();
				listener.onLeaveApplication();
			}
		};
        
        View banner = getBanner(serverParameter, customEventExtra, activity, prefs, bannerListener);
        
        frameLayout.addView(banner, new FrameLayout.LayoutParams(adSize.getWidthInPixels(activity), adSize.getHeightInPixels(activity), Gravity.CENTER));
	}

	private View getBanner(String serverParameter, Object customEventExtra, Activity activity, AdPreferences prefs, BannerListener bannerListener) {
		if (serverParameter != null) {
			if (serverParameter.equalsIgnoreCase("BannerMode.STANDARD")) {
				return new BannerStandard(activity, prefs, bannerListener);
			} else if (serverParameter.equalsIgnoreCase("BannerMode.THREED")) {
				return new Banner3D(activity, prefs, bannerListener);
			} else if (serverParameter.equalsIgnoreCase("BannerMode.AUTO")) {
				return new Banner(activity, prefs, bannerListener);
			}
		}
		if (customEventExtra instanceof StartAppBannerExtras) {
			switch (((StartAppBannerExtras)customEventExtra).getBannerMode()) {
			case AUTO:
				return new Banner(activity, prefs, bannerListener);
			case STANDARD:
				return new BannerStandard(activity, prefs, bannerListener);
			case THREED:
				return new Banner3D(activity, prefs, bannerListener);
			}
		}
		return new Banner(activity, prefs, bannerListener);
	}

	private AdPreferences extractAdPrefs(Activity activity, MediationAdRequest request, Object customEventExtra) {
		AdPreferences prefs = new AdPreferences();
		setGender(prefs, request);
		setAge(prefs, request);
		setKeywords(prefs, request);
		setLocation(prefs, request);
		return prefs;
	}

	private void setKeywords(AdPreferences prefs, MediationAdRequest request) {
		if (request.getKeywords() != null) {
			StringBuilder sb = new StringBuilder();
			for (String keyWord : request.getKeywords()) {
				sb.append(keyWord + ",");
			}
			prefs.setKeywords(sb.substring(0, sb.length() - 1));
		}
	}

	private void setLocation(AdPreferences prefs, MediationAdRequest request) {
		if (request.getLocation() != null) {
			prefs.setLongitude(request.getLocation().getLongitude());
			prefs.setLatitude(request.getLocation().getLatitude());
		}
	}

	private void setGender(AdPreferences prefs, MediationAdRequest request) {
		if (request.getGender() != null) {
			if (request.getGender() == Gender.MALE) {
				prefs.setGender(SDKAdPreferences.Gender.MALE);
			} else if (request.getGender() == Gender.FEMALE) {
				prefs.setGender(SDKAdPreferences.Gender.FEMALE);
			}
		}
	}

	private void setAge(AdPreferences prefs, MediationAdRequest request) {
		if (request.getAgeInYears() != null) {
			prefs.setAge(request.getAgeInYears());
		}
	}

//	@Override
	public void destroy() {}

}
