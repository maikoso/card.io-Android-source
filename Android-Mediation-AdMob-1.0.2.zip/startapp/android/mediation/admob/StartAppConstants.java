package com.startapp.android.mediation.admob;

public class StartAppConstants {
	
	public static final String WRAPPER_VERSION = "1.0.2";
	
}
