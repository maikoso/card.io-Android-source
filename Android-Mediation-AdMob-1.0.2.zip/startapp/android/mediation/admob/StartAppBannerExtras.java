package com.startapp.android.mediation.admob;

import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEventExtras;

public class StartAppBannerExtras extends StartAppExtras {
	
	public enum BannerMode {
		AUTO, STANDARD, THREED
	}

	private BannerMode bannerMode;
	
	private StartAppBannerExtras(){
		super();
	}
	
	public BannerMode getBannerMode() {
		return bannerMode;
	}
	
	public StartAppExtras setBannerMode(BannerMode bannerMode) {
		this.bannerMode = bannerMode;
		return this;
	}
	
	public static class Builder{
		
		private StartAppBannerExtras extras;
		
		public Builder() {
			extras = new StartAppBannerExtras();
		}
		
		public Builder setBannerMode(BannerMode bannerMode) {
			extras.setBannerMode(bannerMode);
			return this;
		}
		
		public Builder setAdTag(String adTag) {
			extras.setAdTag(adTag);
			return this;
		}
		
		public NetworkExtras build(String label) {
		    CustomEventExtras customEventExtras = new CustomEventExtras();
		    customEventExtras.setExtra(label, extras);
		    
		    return customEventExtras;
		}
		
	}
	
}
